Alternate models that can be used 

API_URL = "https://api-inference.huggingface.co/models/CompVis/stable-diffusion-v1-4" 
API_URL = "https://api-inference.huggingface.co/models/runwayml/stable-diffusion-v1-5" 