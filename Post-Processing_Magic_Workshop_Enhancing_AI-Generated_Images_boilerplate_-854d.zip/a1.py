# Pseudocode for Image Generation and Post-Processing Program

# Function: generate_image_from_text(prompt)
    # Define the API endpoint URL for the Stable Diffusion model.
    # Set up the authorization header using the Hugging Face API key.
    # Create a payload that includes the text prompt.
    # Send a POST request to the API endpoint with the header and payload.
    # If the response indicates success (status code 200):
        # Convert the response content into an image.
        # Return the generated image.
    # Else:
        # Raise an error with the response status and error message.

# Function: post_process_image(image)
    # Increase the brightness of the image:
        # Initialize a brightness enhancer with the original image.
        # Enhance brightness by 20% (using an enhancement factor of 1.2).
    # Enhance the contrast of the image:
        # Initialize a contrast enhancer using the brightened image.
        # Enhance contrast by 30% (using an enhancement factor of 1.3).
    # Apply a soft-focus effect:
        # Use a Gaussian blur filter with an appropriate radius (e.g., radius 2) on the contrast-enhanced image.
    # Return the processed image with all applied effects.

# Main Program Flow
    # Display welcome messages and explain program functionality.
    # Inform the user that they can exit by typing 'exit'.
    # Enter a continuous loop:
        # Prompt the user to enter a text description for an image or 'exit' to quit.
        # If the user types 'exit':
            # Display a goodbye message.
            # Break out of the loop to end the program.
        # Otherwise, for a valid text prompt:
            # Inform the user that the image is being generated.
            # Call the generate_image_from_text function with the user's prompt.
            # Inform the user that post-processing effects are being applied.
            # Call the post_process_image function with the generated image.
            # Display the processed image to the user.
            # Ask the user if they want to save the processed image.
            # If the user confirms (answers 'yes'):
                # Prompt the user for a file name (without extension).
                # Save the processed image with the provided name and a PNG extension.
                # Confirm to the user that the image has been saved.
            # Print a separator or blank line to delineate iterations.
        # Handle any exceptions that occur by displaying an error message.
