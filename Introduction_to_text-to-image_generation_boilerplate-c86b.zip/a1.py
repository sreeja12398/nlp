# 1. IMPORT:
#    - requests
#    - PIL.Image, BytesIO
#    - config with HF_API_KEY

# 2. SET API_URL to the Stable Diffusion endpoint

# 3. FUNCTION generate_image_from_text(prompt):
#    3.1. Prepare headers with "Authorization: Bearer <HF_API_KEY>"
#    3.2. payload = {"inputs": prompt}
#    3.3. Make POST request to API_URL with headers and JSON payload
#        - Raise exception if status code != 200
#    3.4. Check 'Content-Type' for 'image'
#    3.5. If content is an image:
#        - Convert response content to an Image object
#        - Return the Image
#    3.6. Otherwise, raise an exception that the response is not an image

# 4. FUNCTION main():
#    4.1. Print greeting and instructions
#    4.2. While True:
#        4.2.1. Prompt the user for a text description
#        4.2.2. If user enters 'exit', break loop
#        4.2.3. Call generate_image_from_text(prompt)
#        4.2.4. Display the generated image
#        4.2.5. Ask user if they want to save the image
#               - If yes, ask for a file name and save as PNG
#    4.3. Print exit message

# 5. IF __name__ == "__main__":
#    5.1. Call main()
